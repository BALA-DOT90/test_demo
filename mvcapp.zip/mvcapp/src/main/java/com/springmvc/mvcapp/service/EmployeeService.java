package com.springmvc.mvcapp.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springmvc.mvcapp.model.Employee;
import com.springmvc.mvcapp.repository.EmployeeRepository;
@Service
public class EmployeeService {
    @Autowired
    EmployeeRepository repository;
    public List<Employee> listAll(){

        return(List<Employee>) repository.findAll();
    }
    public void create(Employee employee) {

        repository.save(employee);
    }
    public Employee updateid(Long id) {

        return repository.findById(id).get();
    }
    public void delete(Long id) {

        repository.deleteById(id);
    }
}
