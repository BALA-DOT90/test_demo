package com.springmvc.mvcapp.repository;

import com.springmvc.mvcapp.model.Employee;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepository extends CrudRepository<Employee, Long> {
}
