package com.springmvc.mvcapp.controller;

import com.springmvc.mvcapp.model.Employee;
import com.springmvc.mvcapp.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class EmployeeController {
    @Autowired
    private EmployeeService service;
    @RequestMapping(value="/all",method=RequestMethod.GET)
    public ModelAndView viewIndexPage() {
        ModelAndView model = new ModelAndView("emp_list");
        List<Employee> empList = service.listAll();
        model.addObject("empList", empList);
        return model;
    }
    @RequestMapping(value="/new_add", method=RequestMethod.GET)
    public ModelAndView viewNewEmployeeForm() {
        ModelAndView model = new ModelAndView();
        Employee emp = new Employee();
        model.addObject("empForm", emp);
        model.setViewName("emp_form");
        return model;
    }

    @RequestMapping(value = "/save_employee", method = RequestMethod.POST)
    public ModelAndView  addNewEmployee(@ModelAttribute("empForm") Employee emp) {
        service.create(emp);
        return new ModelAndView("redirect:/all");
    }
    @RequestMapping(value="/edit/{id}", method=RequestMethod.GET)
    public ModelAndView  viewEditEmployeeForm(@PathVariable(name = "id") long id) {
        ModelAndView model = new ModelAndView();
        Employee emp = service.updateid(id);
        model.addObject("empForm", emp);
        model.setViewName("emp_form");
        return model;

    }

    @RequestMapping(value="/delete/{id}", method=RequestMethod.GET)
    public ModelAndView delete(@PathVariable("id") long id) {
        service.delete(id);
        return new ModelAndView("redirect:/all");
    }

}