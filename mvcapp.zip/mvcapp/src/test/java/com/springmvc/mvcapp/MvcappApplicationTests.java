package com.springmvc.mvcapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcappApplicationTests {

	@Test
	void contextLoads() {
	}

}
